package com.bangkit.tpk.activities

import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import com.Bangkit.tpk.R
import kotlinx.android.synthetic.main.activity_about.*

/**
 * Created by Bangkit Wijonarko 12 Juli 2020.
 */

class AboutActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            val window = window
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            window.statusBarColor = Color.parseColor("#FFC107")
        }

        imgCloseAbout.setOnClickListener {
            this.finish()
        }

    }
}
