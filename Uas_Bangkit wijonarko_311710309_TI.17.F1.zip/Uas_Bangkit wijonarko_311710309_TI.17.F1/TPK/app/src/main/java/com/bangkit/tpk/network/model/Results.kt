package com.bangkit.tpk.network.model

data class Results(

        var geometry: Geometry?,
        var name: String?,
        var vicinity: String?,
        var place_id: String?

)