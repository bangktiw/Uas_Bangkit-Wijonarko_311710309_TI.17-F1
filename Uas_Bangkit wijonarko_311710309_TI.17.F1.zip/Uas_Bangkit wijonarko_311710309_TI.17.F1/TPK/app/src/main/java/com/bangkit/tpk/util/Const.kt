package com.bangkit.tpk.util

class Const {

    companion object {
        var lat: Double? = null
        var lng: Double? = null
    }

}