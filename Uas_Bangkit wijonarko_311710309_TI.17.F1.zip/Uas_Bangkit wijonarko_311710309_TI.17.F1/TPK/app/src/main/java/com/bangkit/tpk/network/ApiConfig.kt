package com.bangkit.tpk.network

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

/**
 * Created by Bangkit Wijonarko On 12 Juli 2020.
 */

class ApiConfig {

    companion object {
        const val BASE_URL = "https://maps.googleapis.com/maps/api/place/"
        const val API_KEY = "YOUR API KEY"
    }

    private fun retrofit(): Retrofit {

        return Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()

    }

    fun instance(): ApiInterface {
        return retrofit().create(ApiInterface::class.java)
    }

}
