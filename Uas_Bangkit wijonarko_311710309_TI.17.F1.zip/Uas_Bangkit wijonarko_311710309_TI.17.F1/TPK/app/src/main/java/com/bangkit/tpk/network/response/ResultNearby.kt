package com.bangkit.tpk.network.response

import com.bangkit.tpk.network.model.Results
import com.google.gson.annotations.SerializedName

data class ResultNearby(

        @SerializedName("results")
        var results: ArrayList<Results>?

)