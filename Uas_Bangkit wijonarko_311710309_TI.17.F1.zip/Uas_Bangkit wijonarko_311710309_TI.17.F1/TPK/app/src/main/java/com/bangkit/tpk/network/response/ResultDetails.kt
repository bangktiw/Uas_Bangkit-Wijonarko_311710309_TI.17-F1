package com.bangkit.tpk.network.response

import com.bangkit.tpk.network.model.Result
import com.google.gson.annotations.SerializedName

data class ResultDetails(

        @SerializedName("result")
        var result: Result

)