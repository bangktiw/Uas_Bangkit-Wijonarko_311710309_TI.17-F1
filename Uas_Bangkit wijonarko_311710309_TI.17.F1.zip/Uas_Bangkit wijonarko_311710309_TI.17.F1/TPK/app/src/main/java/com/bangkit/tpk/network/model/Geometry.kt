package com.bangkit.tpk.network.model

data class Geometry(

        var location: Location?

)