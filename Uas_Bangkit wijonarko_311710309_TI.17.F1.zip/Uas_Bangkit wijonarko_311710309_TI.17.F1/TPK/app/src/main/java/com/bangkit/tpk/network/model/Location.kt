package com.bangkit.tpk.network.model

data class Location(

        var lat: String?,
        var lng: String?

)