package com.bangkit.tpk.network.model

data class Result(

        var formatted_address: String?,
        var formatted_phone_number: String?,
        var geometry: Geometry?,
        var name: String?

)